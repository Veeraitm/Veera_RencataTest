﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using WpfRencataTest.Command;
using WpfRencataTest.Model;
using DataAccess;
using WpfRencataTest.EmpService;
using System.Windows.Media.Animation;
using System.IO;
using Microsoft.Win32;

namespace WpfRencataTest.ViewModel
{
  public class EmployeeViewModel : ViewModelBase
    {
        #region Fields
        EmpService.EmployeeServiceClient _service;
        private EmployeeModel _employee;
        private ObservableCollection<EmployeeModel> _employees;
        private ICommand _SubmitCommand;
        private ICommand _updateCommand;
        private ICommand _deleteCommand;
        private List<Employee> _Emplist;
        #endregion

        #region constructor
        public EmployeeViewModel()
        {
            EmployeeModel = new EmployeeModel();
            Employees = new ObservableCollection<EmployeeModel>();
            _service = new EmpService.EmployeeServiceClient();
            GetData();     
        }
        #endregion

        #region Poplate Data
        public void GetData()
        {
            _Emplist = new List<Employee>();
            _Emplist = _service.GetAll();
            Employees = new ObservableCollection<EmployeeModel>();
            foreach (var emp in _Emplist)
            {
                EmployeeModel employmodel = new EmployeeModel();
                employmodel.EmpID = emp.EmpID;
                employmodel.EmpName = emp.EmpName;
                employmodel.Designation = emp.Designation;
                employmodel.Age = emp.Age;
                employmodel.Address1 = emp.Address1;
                employmodel.Adress2 = emp.Adress2;
                Employees.Add(employmodel);
            }
        }
        #endregion

        #region propeties
        public EmployeeModel EmployeeModel
        {
            get
            {
                return _employee;
            }
            set
            {
                _employee = value;
                OnPropertyChanged("EmployeeModel");
            }
            
        }
       
        public ObservableCollection<EmployeeModel> Employees
        {
            get
            {
                return _employees;
            }
            set
            {
                _employees = value;
                OnPropertyChanged("Employees");
            }
        }
        public ICommand SubmitCommand
        {
            get
            {
                if (_SubmitCommand == null)
                {
                    _SubmitCommand = new RelayCommand(param => this.Submit(), null);
                }
                return _SubmitCommand;
            }
        }           

        public ICommand UpdateCommand
        {
            get
            {
                if (_updateCommand == null)
                {
                    _updateCommand = new RelayCommand(param => this.Update(), null);
                }
                return _updateCommand;
            }
        }

        public ICommand DeleteCommand
        {
            get
            {
                if (_deleteCommand == null)
                {
                    _deleteCommand = new RelayCommand(param => this.Delete(), null);
                }
                return _deleteCommand;
            }
        }

        #endregion

        #region methods
        private void Submit()
        {
            try
            {
                Employee emp = new Employee();
                emp.EmpID = EmployeeModel.EmpID;
                emp.Designation = EmployeeModel.Designation;
                emp.EmpName = EmployeeModel.EmpName;
                emp.Age = EmployeeModel.Age;
                emp.Address1 = EmployeeModel.Address1;
                emp.Adress2 = EmployeeModel.Adress2;
                _service.Add(emp);
                GetData();
                EmployeeModel = new EmployeeModel();
            }
            catch(Exception ex)
            {
                ex.Message.ToString();
            }
        }      
        private void Update()
        {
            try
            { 
            
            Employee emp = new Employee();
            emp.EmpID = EmployeeModel.EmpID;
            emp.Designation = EmployeeModel.Designation;
            emp.EmpName = EmployeeModel.EmpName;
            emp.Age = EmployeeModel.Age;
            emp.Address1 = EmployeeModel.Address1;
            emp.Adress2 = EmployeeModel.Adress2;
            _service.Update(emp);
            GetData();
            EmployeeModel = new EmployeeModel();

           }
            catch(Exception ex)
            {
                ex.Message.ToString();
            }
        }
        private void Delete()
        {
            try
            {
                Employee emp = new Employee();
                emp.EmpID = EmployeeModel.EmpID;
                emp.Designation = EmployeeModel.Designation;
                emp.EmpName = EmployeeModel.EmpName;
                emp.Age = EmployeeModel.Age;
                emp.Address1 = EmployeeModel.Address1;
                emp.Adress2 = EmployeeModel.Adress2;
                _service.Delete(emp);
                GetData();
            }
            catch(Exception ex)
            {
                ex.Message.ToString();
            }
          
        }
        #endregion

    }
}

