﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
namespace DataAccess
{
   
    public class DAL
    {
        private EmpEntity empdb = new EmpEntity();

        public void Add(Employee emp)
        {
            empdb.Employees.Add(emp);
            empdb.SaveChanges();
        }
        public List<Employee> GetAll()
        {
            return empdb.Employees.ToList();
        }
        public void Update(Employee emp)
        {
            Employee updateemp = empdb.Employees.FirstOrDefault(b => b.EmpID == emp.EmpID);
            if (updateemp != null)
            {
                updateemp.EmpName = emp.EmpName;
                updateemp.Designation = emp.Designation;
                updateemp.Age = emp.Age;
                updateemp.Address1 = emp.Address1;
                updateemp.Adress2 = emp.Adress2;             
                empdb.SaveChanges();
            }
            
        }
        public void Delete(Employee emp)
        {
            Employee deleteemp = empdb.Employees.FirstOrDefault(b => b.EmpID == emp.EmpID);
            empdb.Employees.Remove(deleteemp);
            empdb.SaveChanges();
        }
    }
}
