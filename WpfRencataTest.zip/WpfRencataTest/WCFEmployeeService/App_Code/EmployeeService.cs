﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using DataAccess;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "EmployeeService" in code, svc and config file together.
public class EmployeeService : IEmployeeService
{
    DAL _dal = new DAL(); 
    public void Add(Employee emp)
    {
        _dal.Add(emp);
    }  

    public void Delete(Employee emp)
    {
        _dal.Delete(emp);
    }

    public List<Employee> GetAll()
    {
        return _dal.GetAll();
    }

    public void Update(Employee emp)
    {
        _dal.Update(emp);
    }

}
